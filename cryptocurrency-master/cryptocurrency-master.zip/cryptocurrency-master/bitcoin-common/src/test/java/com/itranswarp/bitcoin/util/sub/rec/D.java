package com.itranswarp.bitcoin.util.sub.rec;

// should be excluded:
public class D {

}
