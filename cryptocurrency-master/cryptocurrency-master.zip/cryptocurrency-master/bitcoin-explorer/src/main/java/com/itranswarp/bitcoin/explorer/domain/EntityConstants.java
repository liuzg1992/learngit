package com.itranswarp.bitcoin.explorer.domain;

public interface EntityConstants {

	/**
	 * Hash length = 64-char hex string = 32 bytes = 256 bits
	 */
	int HASH_LENGTH = 64;

}
